MORAIRA GITHUB ACTION — AUTOMATISCHE FEED-UPDATE

Plaats deze bestanden in de bestaande GitHub-repository moraira-agenda:

.github/workflows/update-moraira.yml
scripts/update_calendar.py

Hoe het werkt:
- Iedere woensdag draait GitHub Actions automatisch.
- Het script leest de huidige moraira.ics.
- Het controleert ingestelde internetbronnen.
- Bestaande agenda-items worden standaard behouden.
- Gevonden/geverifieerde items worden toegevoegd of bijgewerkt.
- Als moraira.ics wijzigt, commit GitHub Actions het bestand automatisch.
- Netlify ziet de GitHub-commit en publiceert daarna vanzelf opnieuw.
- Apple Agenda blijft dezelfde abonnement-URL gebruiken.

EERSTE KEER:
1. Upload beide bestanden naar GitHub in exact deze mappen.
2. Open GitHub > repository moraira-agenda > Actions.
3. Kies 'Update Moraira calendar'.
4. Klik 'Run workflow' om handmatig te testen.
5. Controleer daarna of een commit 'Update Moraira calendar' verschijnt.
6. Netlify zou daarna automatisch opnieuw deployen.

LET OP:
De meegeleverde parser is bewust conservatief. Hij verwijdert geen evenementen automatisch.
Bron-specifieke parsing kan later verder worden uitgebreid.